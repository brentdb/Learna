# Thinkst Technical Evaluation
-------------------------------------------

## Project setup
I've used a local json file for accessing API locally. In order to run this, json-server needs to be installed.

npm install -g json-server

### Compiles and hot-reloads for development
```
npm run serve

```
### Run json server
```
json-server --watch data/device-data.json 
