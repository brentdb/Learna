import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Incidents from '../views/devices/Incidents.vue'
import DeviceDetails from '../views/devices/DeviceDetails.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/devices/incidents',
    name: 'Incidents',
    component: Incidents
  },
  {
    path: '/devices/:device_id',
    name: 'DeviceDetails',
    component: DeviceDetails
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
