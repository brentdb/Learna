<template>
  <div class="incidents">
    <aside>
      <figure class="logo"><img alt="Vue logo" src="../../assets/images/canary_logo_light@2x.png"></figure>
      <nav>
        <router-link to="/">Dashboard</router-link>
        <router-link :to="{ name: 'Incidents' }">Incidents</router-link>
      </nav>
    </aside>
    <section id="dashboard-container">
      <h1>Incident Reports - <span>Alerts</span></h1>
      <table>
        <thead>
          <th>Node ID</th>
          <th>Description</th>
          <th>DST Host</th>
          <th>SRC Host</th>
          <th>Date Created</th>
          <th>Key</th>
        </thead>
        <tbody>          
            <tr v-for="alert in alerts" :key="alert.device_id">
              <td>{{ alert.node_id }}</td>
              <td>{{ alert.description }}</td>
              <td>{{ alert.dst_host }}</td>
              <td>{{ alert.src_host }}</td>
              <td>{{ alert.created }}</td>
              <td>{{ alert.key }}</td>
            </tr>
        </tbody>
      </table>      
    </section>
  </div>
</template>

<script>

export default {
   data() {
      return{
          device_list: [], 
          alerts: []
      }
  },
  mounted(){
      fetch('http://localhost:3000/device_list')
          .then(res => res.json())
          .then(data => this.device_list = data)
          .catch(err => console.log(err.message))

      fetch('http://localhost:3000/alerts')
          .then(res => res.json())
          .then(data => this.alerts = data)
          .catch(err => console.log(err.message))
  }
}
</script>

<style lang="scss" scoped>
  table{
    width: 100%;
    border-collapse: collapse;
    thead{
      th{
        padding: 5px;
        text-align: left;
        border: solid 1px #cccccc;

        &:nth-child(5){width:120px;}
      }
    }
    tbody{
      td{
        font-size: 0.85rem;
        padding: 5px;
        border-collapse: collapse;
        border: solid 1px #cccccc;
        
      }
    }
  }
</style>

