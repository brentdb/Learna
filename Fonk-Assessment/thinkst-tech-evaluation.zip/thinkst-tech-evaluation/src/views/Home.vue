<template>
  <div class="dashboard">
    <aside>
      <figure class="logo"><img alt="Vue logo" src="../assets/images/canary_logo_light@2x.png"></figure>
      <nav>
        <router-link to="/">Dashboard</router-link>
        <router-link :to="{ name: 'Incidents' }">Incidents</router-link>
      </nav>
    </aside>
    <section id="dashboard-container">
      <h1>Dashboard - <span>Devices List</span></h1>
      <div class="device-container">
        <div class="device-box" v-for="device in device_list" :key="device.device_id">
          <figure><img alt="Vue logo" src="../assets/images/canary_logo_icon.png"></figure>
          <h3>Node ID:</h3>
          <h5>{{ device.node_id }}</h5>
          <h4><b>Device Description:</b></h4>
          <p>{{ device.description }}</p>
          <h4><b>Device IP Address:</b></h4>
          <p>{{ device.ip_address }}</p>
          <p><b>Device Live:</b> {{ device.device_live }}</p>
          <router-link class="view-device-btn" :to="{ name: 'DeviceDetails', params: { device_id: device.device_id}}">View Device</router-link>
        </div>
      </div>

    </section>
  </div>
</template>

<script>

export default {
  data() {
      return{
          device_list: []
          
      }
  },
  mounted(){
      fetch('http://localhost:3000/device_list')
          .then(res => res.json())
          .then(data => this.device_list = data)
          .catch(err => console.log(err.message))
  }
}
</script>

<style lang="scss">

  .device-container{
      width: 100%;
      padding:  0;      

    .device-box{
      width: 20.333%;
      height: 320px;
      position: relative;
      float: left;
      margin: 0 3% 3% 0;
      padding: 20px;
      -webkit-border-radius:5px;
      -moz-border-radius:5px;
      border-radius:5px;  
      -webkit-box-shadow: 0px 8px 24px rgba(149, 157, 165,0.2);
      -moz-box-shadow: 0px 8px 24px rgba(0, 0, 0, 0.2);
      box-shadow: 0px 8px 24px rgba(149, 157 ,165,0.2);
      border: solid 1px #eeeeee;

      figure{
        width: 30px;
        height: 30px;
        display: block;
        margin: 0 auto 15px auto;

        img{
          width: 30px;
          height: 30px;
          -webkit-border-radius:100%;
          -moz-border-radius:100%;
          border-radius:100%;  
          -webkit-box-shadow: 0px 8px 24px rgba(149, 157, 165,0.2);
          -moz-box-shadow: 0px 8px 24px rgba(0, 0, 0, 0.2);
          box-shadow: 0px 8px 24px rgba(149, 157 ,165,0.2);
          border: solid 1px #eeeeee;
        }
      }

      h3,h5{
        text-align: center;
        padding: 5px 0 0 0;
        margin:0;
      }

      h4{
        padding: 15px 0 0 0;
        margin:0;
      }

      p{
        padding: 0;
        margin:0;
      }

      .view-device-btn{
        width:70%;
        display:block;
        font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
        line-height: 1.5;
        color: #ffffff;
        text-align: center;
        font-weight: 600;
        text-transform: uppercase;   
        text-decoration: none;  
        margin: 10px auto; 
        padding: 10px 25px;  
        position: absolute;
        bottom: 10px;
        background: #8AD736;
        -webkit-border-radius:4px;
        -moz-border-radius:4px;
        border-radius:4px;
        -webkit-box-shadow: 0 2px 9px 0 rgba(74, 74, 74,0.4);
        -moz-box-shadow: 0 2px 9px 0 rgba(74, 74, 74,0.4);
        box-shadow: 0 2px 9px 0 rgba(74, 74, 74,0.4);
      }
    }
  }
</style>
