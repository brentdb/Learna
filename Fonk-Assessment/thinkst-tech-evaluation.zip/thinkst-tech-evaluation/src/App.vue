<template>
  
  <router-view/>
</template>

<style lang="scss">

body,html{
  margin:0;
  padding: 0;
  background: #008479;
  background: linear-gradient(135deg, #008479 0%, #02f15d 80%);
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#008479', endColorstr='#02f15d',GradientType=1 );
}

#app {
    width: 100%;
    height: 100vh;
    max-height: 100vh;
    font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-weight: normal;
    line-height: 1.5;
    color: #4A4A4A;
    overflow: auto;
  }

  nav{
    height: 100vh;
    padding: 0 15px;
    a{
      display:block;
      font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
      font-weight: normal;
      line-height: 1.5;
      color: #eeeeee;
      font-weight: normal;
      padding: 10px 5px;
      text-decoration: none;
      border-bottom: solid 1px rgba(255,255,255,0.5);

      &:hover,
      &.router-link-active{
        color: #ffffff;
        text-decoration: underline;
        font-weight: 700;
      }

    }
  }


aside{
  width: 15vw;
  float:left;
    figure.logo{
      width: 203px;
      padding:15px;
      margin:0;
      img{
        width:100%;
      }
    }
}

section#dashboard-container{
  width: 80vw;
  height: auto;
  float:left;
  margin:75px 0 0 0;
  padding:25px;
  -webkit-border-radius:5px;
  -moz-border-radius:5px;
  border-radius:5px;
  background: #ffffff;

  h1{
    margin:0;
    padding:0 0 25px 0;

    span{
      font-size:1rem;
    }
  }
}

</style>
