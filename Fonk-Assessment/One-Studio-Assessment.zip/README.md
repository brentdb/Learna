# Fonk Assessment
-------------------------------------------

## Project setup

In order to run gulp, one must use node version 11.15.0 and Gulp local version 3.9.1

npm install

Use command:
gulp

Node Version:
v11.15.0

#Gulp setup:
-------------------------------------------
CLI version: 2.3.0
Local version: 3.9.1

